# Colab Alive

A chrome extension that keeps Colab notebooks alive — prevents the browser timeout

How it works — a few lines of JS code are injected if you have a colab tab open

Code credit: https://medium.com/@shivamrawat_756/how-to-prevent-google-colab-from-disconnecting-717b88a128c0

Rate the extension on Chrome webstore if you like it :)